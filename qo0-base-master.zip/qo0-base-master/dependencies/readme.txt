dependencies versions:

- imgui: 1.75 (modified)
- nlohman json: 3.7.3
- freetype: 2.10.2
- fmt: 7.0.1
- minhook: 1.3.3
