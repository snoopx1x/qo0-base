to convert fonts into bytes
compile imgui's binary_to_compressed_c
open cmd (or powershell) with shift+right click

command for cmd:
	binary_to_compressed_c.exe [FONT_NAME.TTF] [OUTPUT_NAME]
command for powershell:
	.\binary_to_compressed_c.exe [FONT_NAME.TTF] [OUTPUT_NAME]
